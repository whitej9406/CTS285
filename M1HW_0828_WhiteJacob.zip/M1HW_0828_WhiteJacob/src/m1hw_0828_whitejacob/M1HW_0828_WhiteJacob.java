/*
 *
 *
 *
 */
package m1hw_0828_whitejacob;
import java.util.Scanner;
public class M1HW_0828_WhiteJacob {

    public static void main(String[] args) 
    {
        
        int n1 = 0;
        int n2 = 0;
        double number1 = 0;
        double number2 = 0;
        double total = 0;
        Scanner keyboard = new Scanner(System.in);
        Weclome();
        System.out.println("1. Add");
        System.out.println("2. Subtact");
        System.out.println("3. Divide");
        System.out.println("4. Multiply");
        System.out.println("5. Exit");
        System.out.print("Enter a number: ");
        n1 = keyboard.nextInt();
       
        
        
        if (n1 == 1){
            System.out.println("Add");
            System.out.print("Enter a number: ");
            number1 = keyboard.nextDouble();
            System.out.print("Enter a number: ");
            number2 = keyboard.nextDouble();
            total = number1 + number2;
            System.out.println(number1 + " + "+ number2 + " = "+ total);                                   
        } else if (n1 == 2){
            System.out.println("Subtract");
            System.out.print("Enter a number: ");
            number1 = keyboard.nextDouble();
            System.out.print("Enter a number: ");
            number2 = keyboard.nextDouble();
            total = number1 - number2;
            System.out.println(number1 + " - " + number2 + " = " + total);
        } else if (n1 == 3){
            System.out.println("Divide");
            System.out.print("Enter a number: ");
            number1 = keyboard.nextDouble();
            System.out.print("Enter a number: ");
            number2 = keyboard.nextDouble();
            total = number1 / number2;
            System.out.println(number1 + " / " + number2 + " = " + total);
        } else if (n1 == 4){
            System.out.println("Multiply");
            System.out.print("Enter a number: ");
            number1 = keyboard.nextDouble();
            System.out.print("Enter a number: ");
            number2 = keyboard.nextDouble();
            total = number1 * number2;
            System.out.println(number1 + " * " + number2 + " = " + total);            
        }
        System.out.println("1. Repeat");
        System.out.println("2. Main Menu");
        System.out.print("Enter a number: ");
        n2 = keyboard.nextInt();
        
        if (n2 == 1){
            
        }else if (n2 == 2){
            System.out.println("1. Add");
            System.out.println("2. Subtact");
            System.out.println("3. Divide");
            System.out.println("4. Multiply");
            System.out.println("5. Exit");
            System.out.print("Enter a number: ");
            n1 = keyboard.nextInt();
        }
        
        
        

    }
    
    
    public static void Weclome()
    {
        System.out.println("Welcome to the calculator program.");
    }
    
    public static void Goodbye()
    {
        System.out.println("Goodbye.");
    }
    

}
